<?php 
include 'src/includes/header.php'; 
include 'src/includes/sidenav.php'; 
require_once 'db.php'; // Ensure this path is correct and the file properly sets up your database connection

// Fetch tickets from the database
$perPage = 10;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $perPage;

$sql = "SELECT * FROM service_requests ORDER BY request_id ASC LIMIT $offset, $perPage";
$result = $conn->query($sql);

$totalSql = "SELECT COUNT(*) as total FROM service_requests";
$totalResult = $conn->query($totalSql);
$totalRow = $totalResult->fetch_assoc();
$totalPages = ceil($totalRow['total'] / $perPage);

// Create SQL query for searching
if (!empty($search)) {
    $search = $conn->real_escape_string($search);
    $whereClause = "WHERE `request_id` LIKE '%$search%' OR `category` LIKE '%$search%' OR `institute` LIKE '%$search%' OR `priority` LIKE '%$search%' OR `ticket_status` LIKE '%$search%'";
} else {
    $whereClause = "";
}


$sql = "SELECT * FROM service_requests $whereClause ORDER BY request_id ASC LIMIT $offset, $perPage";
$result = $conn->query($sql);

$totalSql = "SELECT COUNT(*) as total FROM service_requests $whereClause";
$totalResult = $conn->query($totalSql);
$totalRow = $totalResult->fetch_assoc();
$totalPages = ceil($totalRow['total'] / $perPage);


// ------ FOR SELECT HOW MANY CAN SHOW TO TABLE

$perPageOptions = [10, 20, 50, 'all'];  // Allowed per-page options
$defaultPerPage = 10;

// Validate and set the number of entries per page
$perPage = isset($_GET['perPage']) && in_array($_GET['perPage'], $perPageOptions) ? $_GET['perPage'] : $defaultPerPage;

// Get the current page number or default to 1
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

// Check if 'all' is selected
if ($perPage === 'all') {
    // If 'all' is selected, fetch all records without a LIMIT clause
    $sql = "SELECT * FROM service_requests ORDER BY request_id ASC";
    // Only one page needed if showing all entries
    $totalPages = 1;
} else {
    // Calculate the offset for LIMIT clause
    $offset = ($page - 1) * (int)$perPage;
    // SQL query with LIMIT to fetch subset of records
    $sql = "SELECT * FROM service_requests ORDER BY request_id ASC LIMIT $offset, $perPage";
    
    // Calculate the total number of pages
    $totalSql = "SELECT COUNT(*) as total FROM service_requests";
    $totalResult = $conn->query($totalSql);
    $totalRow = $totalResult->fetch_assoc();
    $totalPages = ceil($totalRow['total'] / $perPage);
}
$result = $conn->query($sql);
?>

<div id="layoutSidenav_content">
    <main>
        <div class="container mt-4">
        <div class="actions-with-search">
        <div class="btn-container" role="group" aria-label="Ticket actions">
                <button type="button" class="btn-tickets">+ Ticket</button>
                <input type="text" id="searchInput" class="form-control search-bar" class="fa fa-search" placeholder="Search tickets...">

            </div>
        </div>
            <div class="table-responsive-tickets">
                <table class="table table-striped">
<thead>
    <tr>
        <th class="th-itm" scope="col">
            <!-- Checkbox column -->
        </th>
        <th class="th-itm" scope="col">Ticket ID</th>
        <th class="th-itm" scope="col">
    Priority
    <select id="filter-priority" class="form-control filter-dropdown" style="width: auto; display: inline-block; padding: 0 8px;">
        <option value="">All</option>
        <option value="high">High</option>
        <option value="medium">Medium</option>
        <option value="low">Low</option>
    </select>
</th>
<th class="th-itm" scope="col">
    Category
    <select id="filter-category" class="form-control filter-dropdown" style="width: auto; display: inline-block; padding: 0 8px;">
        <option value="">All</option>
        <option value="Network">Network</option>
        <option value="Computer">Computer</option>
        <option value="System">System</option>
        <option value="Others">Others</option>
    </select>
</th>
<th class="th-itm" scope="col">
    Institute/Office
    <select id="filter-institute" class="form-control filter-dropdown" style="width: auto; display: inline-block; padding: 0 8px;">
        <option value="">All</option>
        <!-- Populate dynamically if possible -->
    </select>
</th>
<th class="th-itm" scope="col">
    Status
    <select id="filter-status" class="form-control filter-dropdown" style="width: auto; display: inline-block; padding: 0 8px;">
        <option value="">All</option>
        <option value="open">Open</option>
        <option value="close">Closed</option>
        <option value="pending">Pending</option>
    </select>
</th>

<th class="th-itm" scope="col">
    <div class="date-filter">
        Date
        <input type="date" id="filter-date-start" class="form-control date-input">
  
        <input type="date" id="filter-date-end" class="form-control date-input">
    </div>
</th>

        <th class="th-itm" scope="col">Actions</th>
    </tr>
</thead>
                    <tbody>            
                        <?php if ($result->num_rows > 0): ?>
                            <?php while($row = $result->fetch_assoc()): ?>
                                <tr>
                                <td class="td-items"><input type="checkbox" name="selected_tickets[]" value="<?php echo $row['id']; ?>"></td>
                                <td class="td-items"><?php echo $row['request_id']; ?></td>
                                <td class="td-items"><?php echo $row['priority']; ?></td>
                                <td class="td-items"><?php echo $row['category']; ?></td>
                                <td class="td-items"><?php echo htmlspecialchars($row['institute']); ?></td>
                                <td class="td-items"><?php echo $row['ticket_status'];?></td>
                                <td class="td-items"><?php echo $row['date']; ?></td>
                                <td class="td-items">
                                    <button type="button" class="btn btn-primary btn-sm view-btn" 
                                        data-request-id="<?php echo $row['request_id']; ?>"
                                        data-description="<?php echo htmlspecialchars($row['description']); ?>"
                                        data-priority="<?php echo $row['priority']; ?>"
                                        data-ticket-status="<?php echo $row['ticket_status']; ?>"
                                        data-category="<?php echo $row['category']; ?>"
                                        data-supervisor="<?php echo htmlspecialchars($row['supervisor']); ?>"
                                        data-institute="<?php echo htmlspecialchars($row['institute']); ?>"
                                        data-location="<?php echo htmlspecialchars($row['location']); ?>"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>"
                                        data-contact="<?php echo $row['contact']; ?>"
                                        data-email="<?php echo $row['email']; ?>"
                                        data-date="<?php echo $row['date']; ?>">View
                                    </button>
                                </td>

                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="13">No tickets found</td></tr>
                        <?php endif; ?>
                    </tbody>
                    
                </table>
                
            </div>
            <div class="flex-container">

        <!-- Dropdown for selecting per page count -->
        <div id="dropdownContainer">
            <select id="perPageSelect" onchange="location = this.value;">
                <option value="">show data </option>
                <option value="?perPage=10">10</option>
                <option value="?perPage=20">20</option>
                <option value="?perPage=50">50</option>
                <option value="?perPage=all">Show All</option>
            </select>
        </div>

        <!-- Pagination Section -->
        <?php if ($totalPages > 1): ?>
        <nav aria-label="Page navigation example" class="pagination-container">
            <ul class="pagination">
                <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <li class="page-item <?= ($i === $page) ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                </li>
                <?php endfor; ?>
            </ul>
        </nav>
        <?php endif; ?>
    </div>
    
</main>
    
    <?php include 'src/includes/footer.php'; ?>
</div>


<!-- Modal HTML structure -->
<div id="ticketModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <h2 class="ticketdetails_title">Ticket Details</h2>
        <p><strong>Ticket ID:</strong> <span id="modal-ticket-id"></span></p>
        <p><strong>Description:</strong> <span id="modal-description"></span></p>
        <p><strong>Priority:</strong> <span id="modal-priority"></span></p>
        <p><strong>Status:</strong> <span id="modal-status"></span></p>
        <p><strong>Category:</strong> <span id="modal-category"></span></p>
        <p><strong>Supervisor:</strong> <span id="modal-supervisor"></span></p>
        <p><strong>Institute/Office:</strong> <span id="modal-institute"></span></p>
        <p><strong>Location:</strong> <span id="modal-location"></span></p>
        <p><strong>Name:</strong> <span id="modal-name"></span></p>
        <p><strong>Contact:</strong> <span id="modal-contact"></span></p>
        <p><strong>Email:</strong> <span id="modal-email"></span></p>
        <p><strong>Date Created:</strong> <span id="modal-date"></span></p>
        <div class="modal-button">
            <input type="hidden" name="ticket_id" id="modal-ticket-id-input" value="">
                <button id="editBtn" type="button" class="btn-tickets">Edit</button>
                <button id="approveBtn" class="btn-tickets">Approve</button>
                <div id="approvalModal" class="modal">
                    <div class="modal-content">
                        <!-- Your form for selecting the schedule date -->
                        <span class="approve-modal-close-btn">&times;</span>
                        <form  id="approvalForm">
                            <label id="approve-modal-lab" for="scheduleDate">Select Schedule Date:</label>
                            
                            <input type="date" id="scheduleDate" name="scheduleDate">
                            
                            <button id="modal-approve-btn" type="submit">Approve</button>
                        </form>
                    </div>
                </div>

                <button id="denyBtn" class="btn-tickets">Deny</button>
                <button id="rescheduleBtn" class="btn-tickets">Re-schedule</button>
                <button id="markAsClosedBtn" class="btn-tickets">Mark as Closed</button>

        </div>
    </div>
    
</div>

<script>

document.addEventListener('DOMContentLoaded', function () {

    document.getElementsByClassName('approve-modal-close-btn')[0].addEventListener('click', function() {
    document.getElementById('approvalModal').style.display = 'none';
    });

   // Function to handle approve button click
    // Function to handle approve button click and open the form/modal-for datepicker
function openApprovalForm() {
    // Show your form or modal here
    // For example, if you have a modal with id 'approvalModal', you can display it like this:
    document.getElementById('approvalModal').style.display = 'block';
}

// Event listener for the Approve button
document.getElementById('approveBtn').addEventListener('click', openApprovalForm);

// Function to handle form submission
function submitApprovalForm() {
    var ticketId = document.getElementById('modal-ticket-id-input').value;
    var scheduleDate = document.getElementById('scheduleDate').value;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_ticket.php');
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Handle the response here if needed
            console.log(xhr.responseText);
        }
    };
    xhr.send('ticket_id=' + encodeURIComponent(ticketId) + '&schedule_date=' + encodeURIComponent(scheduleDate) + '&action=approve');

    document.getElementById('approvalModal').style.display = 'none';
}

// Event listener for form submission
document.getElementById('approvalForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission behavior
    submitApprovalForm();
});



    // Function to handle deny button click
    function denyTicket() {
        console.log("deny");
        var ticketId = document.getElementById('modal-ticket-id-input').value;
        console.log("Ticket ID:", ticketId);
    }

    // Function to handle re-schedule button click
    function rescheduleTicket() {
        console.log("resched");
        var ticketId = document.getElementById('modal-ticket-id-input').value;
        console.log("Ticket ID:", ticketId);
    }

    // Function to handle mark as closed button click
    function markAsClosed() {
        console.log("mark as closed");
        var ticketId = document.getElementById('modal-ticket-id-input').value;
        console.log("Ticket ID:", ticketId);
    }

    // Set event listeners for buttons
    document.getElementById('approveBtn').addEventListener('click', approveTicket);
    document.getElementById('denyBtn').addEventListener('click', denyTicket);
    document.getElementById('rescheduleBtn').addEventListener('click', rescheduleTicket);
    document.getElementById('markAsClosedBtn').addEventListener('click', markAsClosed);

    // Show modal when clicking on the button
    document.getElementById('showModalBtn').addEventListener('click', function () {
        showModal();
    });

    // Hide modal when clicking on the close button
    closeButton.addEventListener('click', function () {
        hideModal();
    });

    // Hide modal when clicking outside of it
    window.onclick = function (event) {
        if (event.target == modal) {
            hideModal();
        }
    };
});




</script>



<?php 
$conn->close();
?>
