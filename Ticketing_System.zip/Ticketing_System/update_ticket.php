<?php
require_once 'db.php'; // Include your database connection script

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ticket_id'], $_POST['action'])) {
    try {
        if (empty($_POST['schedule_date'])) {

            throw new Exception("Schedule date is required. Ticket ID: " . $_POST['ticket_id'] . " Schedule Date: " . $_POST['schedule_date']);

        }

        $date = DateTime::createFromFormat('Y-m-d', $_POST['schedule_date']);
        if (!$date) {
            throw new Exception("Invalid date format. Please use YYYY-MM-DD format.");
        }
        
        $schedule = $conn->real_escape_string($date->format('Y-m-d'));
        $ticketId = $conn->real_escape_string($_POST['ticket_id']);
        $action = $_POST['action'];

        switch ($action) {
            case 'approve':
                $updateSql = "UPDATE service_requests SET ticket_status = 'approved', schedule = '$schedule' WHERE request_id = '$ticketId'";
                if ($conn->query($updateSql) === TRUE) {
                    echo 'Ticket approved successfully';
                } else {
                    echo 'Error updating ticket: ' . $conn->error;
                }
                break;
            default:
                echo 'Invalid action';
                break;
                
        }
    } catch (mysqli_sql_exception $e) {
        echo 'Error while processing request: ' . $e->getMessage();
    } catch (Exception $e) {
        echo 'Error: ' . $e->getMessage();
    }
} else {
    echo 'Invalid request';
}


?>
