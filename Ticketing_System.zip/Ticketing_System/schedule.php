<?php include 'src/includes/header.php'; ?>
  
<?php include 'src/includes/sidenav.php'; ?>

<div id="layoutSidenav_content">
    <main>
   
    <div class="schedule-container">
    <div class="schedule-item">
        <div class="date-info">
            <div class="date">March 20, 2024</div>
        </div>
        <div class="item-info">
            <h3>Ticket#202401001</h3>
            <p>Item 1 Description. More description here to make it longer.</p>
        </div>
        <img src="src/images/samplepic.png" alt="Item 1" width="200" height="200">
    </div>
    
    <div class="schedule-item">
        <div class="date-info">
            <div class="date">March 21, 2024</div>
        </div>
        <div class="item-info">
            <h3>Ticket#202401002</h3>
            <p>Item 2 Description. More description here to make it longer.</p>
        </div>
        <img src="src/images/samplepic.png" alt="Item 2" width="200" height="200">
    </div>

    <div class="schedule-item">
        <div class="date-info">
            <div class="date">March 20, 2024</div>
        </div>
        <div class="item-info">
            <h3>Ticket#202401003</h3>
            <p>Item 1 Description. More description here to make it longer.</p>
        </div>
        <img src="src/images/samplepic.png" alt="Item 1" width="200" height="200">
    </div>

    <div class="schedule-item">
        <div class="date-info">
            <div class="date">March 20, 2024</div>
        </div>
        <div class="item-info">
            <h3>Ticket#20240100</h3>
            <p>Item 1 Description. More description here to make it longer.</p>
        </div>
        <img src="src/images/samplepic.png" alt="Item 1" width="200" height="200">
    </div>
</div>


    </main>

    <?php include 'src/includes/footer.php'; ?>
</div>
