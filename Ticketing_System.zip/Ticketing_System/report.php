<?php include 'src/includes/header.php'; ?>

<?php include 'src/includes/sidenav.php'; ?>

<div id="layoutSidenav_content">
    <main>
        <div class="report-content">
            <h2>Report Submission Form</h2>

            <form action="/submit_report" method="post">
                <!-- Form Groups -->
                <div class="report-form-group">
                    <label for="department">Department:</label>
                    <select id="department" name="department">
                        <option value="">Select Department</option>
                        <option value="finance">Finance</option>
                        <option value="operations">Admin</option>
                        <option value="hr">HR</option>
                      
                    </select>
                </div>

                <div class="report-form-group">
                    <label for="personnel">Personnel:</label>
                    <input type="text" id="personnel" name="personnel" placeholder="Enter personnel name(s)">
                </div>

                <div class="report-form-group">
                    <label for="category">Category:</label>
                    <select id="category" name="category">
                        <option value="">Select Category</option>
                        <option value="financial">Financial</option>
                        <option value="operational">Admin</option>
                        <option value="hr">HR</option>
                      
                    </select>
                </div>

                <div class="report-form-group">
                    <label>Priority:</label>
                    <input type="radio" id="high" name="priority" value="high">
                    <label for="high">High</label>
                    <input type="radio" id="medium" name="priority" value="medium">
                    <label for="medium">Medium</label>
                    <input type="radio" id="low" name="priority" value="low">
                    <label for="low">Low</label>
                </div>

                <div class="report-form-group">
                    <label for="start-date">Start Date:</label>
                    <input type="date" id="start-date" name="start_date">
                </div>

                <div class="report-form-group">
                    <label for="end-date">End Date:</label>
                    <input type="date" id="end-date" name="end_date">
                </div>


                <input type="submit" value="Submit Report">
            </form>
        </div>
    </main>

    <?php include 'src/includes/footer.php'; ?>
</div>

