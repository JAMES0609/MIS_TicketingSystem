/*!
    * Start Bootstrap - SB Admin v7.0.7 (https://startbootstrap.com/template/sb-admin)
    * Copyright 2013-2023 Start Bootstrap
    * Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-sb-admin/blob/master/LICENSE)
    */
    // 
// Scripts
// 

window.addEventListener('DOMContentLoaded', event => {

    // Toggle the side navigation
    const sidebarToggle = document.body.querySelector('#sidebarToggle');
    if (sidebarToggle) {
        // Uncomment Below to persist sidebar toggle between refreshes
        // if (localStorage.getItem('sb|sidebar-toggle') === 'true') {
        //     document.body.classList.toggle('sb-sidenav-toggled');
        // }
        sidebarToggle.addEventListener('click', event => {
            event.preventDefault();
            document.body.classList.toggle('sb-sidenav-toggled');
            localStorage.setItem('sb|sidebar-toggle', document.body.classList.contains('sb-sidenav-toggled'));
        });
    }

});



/* ------ this is for view button tickets ------ */


   document.addEventListener('DOMContentLoaded', function() {
    var viewButtons = document.querySelectorAll('.view-btn');
    var modal = document.getElementById('ticketModal');

    viewButtons.forEach(function(button) {
        button.addEventListener('click', function(event) {
            event.preventDefault();
            var requestId = this.getAttribute('data-request-id');
            var description = this.getAttribute('data-description');
            var priority = this.getAttribute('data-priority');
            var ticket_status = this.getAttribute('data-ticket-status');
            var category = this.getAttribute('data-category');
            var supervisor = this.getAttribute('data-supervisor');
            var institute = this.getAttribute('data-institute');
            var location = this.getAttribute('data-location');
            var name = this.getAttribute('data-name');
            var contact = this.getAttribute('data-contact');
            var email = this.getAttribute('data-email');
            var date = this.getAttribute('data-date');

            // Set modal content
            document.getElementById('modal-ticket-id').textContent = requestId;
            document.getElementById('modal-description').textContent = description;
            document.getElementById('modal-priority').textContent = priority;
            document.getElementById('modal-status').textContent = ticket_status;
            document.getElementById('modal-category').textContent = category;
            document.getElementById('modal-supervisor').textContent = supervisor;
            document.getElementById('modal-institute').textContent = institute;
            document.getElementById('modal-location').textContent = location;
            document.getElementById('modal-name').textContent = name;
            document.getElementById('modal-contact').textContent = contact;
            document.getElementById('modal-email').textContent = email;
            document.getElementById('modal-date').textContent = date;
            document.getElementById('modal-ticket-id-input').value = requestId;

            // Display modal
            modal.style.display = 'block';
            modal.querySelector('.modal-content').style.width = '100%';
        });
    });

    var closeButton = document.querySelector('.close');
    closeButton.addEventListener('click', function() {
        modal.style.display = 'none';
    });

    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = 'none';
        }
    };
});

document.addEventListener('DOMContentLoaded', function() {
    var searchInput = document.getElementById('searchInput');

    searchInput.addEventListener('keyup', function() {
        var searchTerm = this.value.trim();

        // Define the URL for fetching data
        var url = searchTerm === '' ? 'path_to_your_php_script.php?page=1' : 'search_tickets.php';

        // Prepare the request body or query string
        var body = searchTerm === '' ? null : 'search=' + encodeURIComponent(searchTerm);
        var method = searchTerm === '' ? 'GET' : 'POST';

        fetch(url, {
            method: method,
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: body
        })
        .then(response => response.json())
        .then(data => updateTable(data))
        .catch(error => console.error('Error:', error));
    });

    function updateTable(data) {
        var tbody = document.querySelector('.table-responsive-tickets tbody');
        tbody.innerHTML = ''; // Clear current table body
        if (data.length) {
            data.forEach(row => {
                var tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="td-items"><input type="checkbox" name="selected_tickets[]" value="${row.id}"></td>
                    <td class="td-items">${row.request_id}</td>
                    <td class="td-items">${row.priority}</td>
                    <td class="td-items">${row.category}</td>
                    <td class="td-items">${row.institute}</td>
                    <td class="td-items">${row.ticket_status}</td>
                    <td class="td-items">${row.date}</td>
                    <td class="td-items">Actions</td> <!-- Update as needed -->
                `;
                tbody.appendChild(tr);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="8">No tickets found</td></tr>';
        }
    }
});
// ------ for filters ------ //
document.addEventListener('DOMContentLoaded', function() {
    var filters = document.querySelectorAll('.filter-dropdown');
    filters.forEach(function(filter) {
        filter.addEventListener('change', function() {
            applyFilters();
        });
    });

    function applyFilters() {
        var priorityFilter = document.getElementById('filter-priority').value;
        var categoryFilter = document.getElementById('filter-category').value;
        var instituteFilter = document.getElementById('filter-institute').value;
        var statusFilter = document.getElementById('filter-status').value;

        var rows = document.querySelectorAll('.table-responsive-tickets tbody tr');
        rows.forEach(function(row) {
            var priority = row.cells[2].textContent;
            var category = row.cells[3].textContent;
            var institute = row.cells[4].textContent;
            var status = row.cells[5].textContent;

            var priorityMatch = !priorityFilter || priority === priorityFilter;
            var categoryMatch = !categoryFilter || category === categoryFilter;
            var instituteMatch = !instituteFilter || institute.includes(instituteFilter);
            var statusMatch = !statusFilter || status === statusFilter;

            if (priorityMatch && categoryMatch && instituteMatch && statusMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    var filters = document.querySelectorAll('.filter-dropdown, .date-filter input');
    filters.forEach(function(filter) {
        filter.addEventListener('change', function() {
            applyFilters();
        });
    });

    function applyFilters() {
        var priorityFilter = document.getElementById('filter-priority').value;
        var categoryFilter = document.getElementById('filter-category').value;
        var instituteFilter = document.getElementById('filter-institute').value;
        var statusFilter = document.getElementById('filter-status').value;
        var startDateFilter = document.getElementById('filter-date-start').value;
        var endDateFilter = document.getElementById('filter-date-end').value;

        var rows = document.querySelectorAll('.table-responsive-tickets tbody tr');
        rows.forEach(function(row) {
            var priority = row.cells[2].textContent;
            var category = row.cells[3].textContent;
            var institute = row.cells[4].textContent;
            var status = row.cells[5].textContent;
            var dateCreated = row.cells[6].textContent; // Assuming this is the index for Date Created

            var priorityMatch = !priorityFilter || priority === priorityFilter;
            var categoryMatch = !categoryFilter || category === categoryFilter;
            var instituteMatch = !instituteFilter || institute.includes(instituteFilter);
            var statusMatch = !statusFilter || status === statusFilter;
            var dateMatch = (!startDateFilter || new Date(dateCreated) >= new Date(startDateFilter)) &&
                            (!endDateFilter || new Date(dateCreated) <= new Date(endDateFilter));

            if (priorityMatch && categoryMatch && instituteMatch && statusMatch && dateMatch) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    }
});



// for page
function handlePerPageChange(value) {
    var newLocation = '?perPage=' + value;
    if (value === 'all') {
        newLocation += '&page=1'; // Ensure that pagination resets when showing all
    }
    location = newLocation;}

