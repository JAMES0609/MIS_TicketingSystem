<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $host = 'localhost';
    $dbname = 'MIS_database';
    $username = 'root';
    $password = '';

    $user = $_POST['username'];
    $pass = $_POST['password'];
    $email = $_POST['email'];
    $name = $_POST['name'];
    $contact_number = $_POST['contact_number'] ?? null; // using null coalescing operator for optional fields
    $department = $_POST['department'] ?? null;
    $supervisor_head = $_POST['supervisor_head'] ?? null;
    $role = $_POST['role'];

    try {
        $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $hashedPassword = password_hash($pass, PASSWORD_DEFAULT);

        $stmt = $conn->prepare("INSERT INTO users (username, password, email, name, contact_number, department, supervisor_head, role) VALUES (:username, :password, :email, :name, :contact_number, :department, :supervisor_head, :role)");
        $stmt->bindParam(':username', $user);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':contact_number', $contact_number);
        $stmt->bindParam(':department', $department);
        $stmt->bindParam(':supervisor_head', $supervisor_head);
        $stmt->bindParam(':role', $role);

        $stmt->execute();

        echo "Registration successful. You can now <a href='login.php'>login</a>.";
    } catch(PDOException $e) {
        if ($e->getCode() == 23000) { // Code for duplicate entry
            echo "An account with this username or email already exists. Please choose a different one.";
        } else {
            echo "Error: " . $e->getMessage();
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Page</title>
    <link rel="stylesheet" href="login.css">

    <style>


body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f4;
    margin: 0;
    padding: 0;
}

.Login-Form {
    width: 100%;
    max-width: 400px;
    margin: 50px auto;
    background: #fff;
    padding: 20px;
    box-shadow: 2px 2px 10px rgba(0,0,0,0.1);
}

.container {
    display: flex;
    flex-direction: column;
}

.container label {
    margin-bottom: 5px;
    font-weight: bold;
}

.container input[type="text"],
.container input[type="password"],
.container input[type="email"],
.container select {
    margin-bottom: 15px;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

.container button {
    background-color: green;
    color: white;
    border: none;
    padding: 10px;
    border-radius: 4px;
    cursor: pointer;
}

.container button:hover {
    background-color: darkgreen !important;
}

@media (max-width: 600px) {
    .Login-Form {
        width: 90%;
        padding: 10px;
    }

    .container button {
        padding: 12px;
    }
}


    </style>
</head>
<body>
<div class="Login-Form">
    <form action="register.php" method="post">
      <div class="container">
        <label for="username"><b>Username</b></label>
        <input type="text" placeholder="Enter Username" name="username" required>

        <label for="password"><b>Password</b></label>
        <input type="password" placeholder="Enter Password" name="password" required>

        <label for="email"><b>Email</b></label>
        <input type="email" placeholder="Enter Email" name="email" required>

        <label for="name"><b>Name</b></label>
        <input type="text" placeholder="Enter Full Name" name="name" required>

        <label for="contact_number"><b>Contact Number</b></label>
        <input type="text" placeholder="Enter Contact Number" name="contact_number">

        <label for="department"><b>Department</b></label>
        <input type="text" placeholder="Enter Department" name="department">

        <label for="supervisor_head"><b>Supervisor/Head</b></label>
        <input type="text" placeholder="Enter Supervisor/Head Name" name="supervisor_head">

        <label for="role"><b>Role</b></label>
        <select name="role" required>
          <option value="Admin">Admin</option>
          <option value="User" selected>User</option>
        </select>

        <button type="submit">Register</button>
      </div>    
    </form>
</div>
</body>
</html>
